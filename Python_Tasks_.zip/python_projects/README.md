# Python Projects

This folder contains four Python practice projects:

1. **BMI Calculator** – calculates Body Mass Index and keeps a record of previous results.
2. **Random Password Generator** – creates passwords using the character options you choose.
3. **Weather App** – looks up current weather and forecast information using OpenWeatherMap.
4. **Chat Application** – demonstrates messaging between clients using Python sockets.

## Getting started
Install Python 3.10 or later. Open the folder for the project you want to try, then follow the commands in that project's `README.md`. Each project also has a `DOCUMENTATION.md` with a little more explanation.

Run a project's tests from its folder with:

```bash
python -m unittest -v
```

Some projects need extra packages or an API key. Check their individual README files before running them.
