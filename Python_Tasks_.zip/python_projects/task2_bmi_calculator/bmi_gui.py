"""BMI Calculator - Advanced tier (tkinter + SQLite + matplotlib)."""
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox

from bmi_core import BMIDatabase, parse_positive, calculate_bmi, classify

try:
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    HAVE_MPL = True
except ImportError:  # graceful message instead of crash
    HAVE_MPL = False


class BMIApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BMI Calculator")
        self.geometry("420x380")
        self.resizable(False, False)
        try:
            self.db = BMIDatabase()
        except sqlite3.Error as err:
            messagebox.showerror("Database error", f"Could not open database:\n{err}")
            self.db = None
        self._build()
        self._refresh_users()

    def _build(self):
        frm = ttk.Frame(self, padding=15)
        frm.pack(fill="both", expand=True)

        ttk.Label(frm, text="User name:").grid(row=0, column=0, sticky="w", pady=4)
        self.user_var = tk.StringVar()
        self.user_box = ttk.Combobox(frm, textvariable=self.user_var, width=22)
        self.user_box.grid(row=0, column=1, pady=4)

        ttk.Label(frm, text="Weight (kg):").grid(row=1, column=0, sticky="w", pady=4)
        self.weight_var = tk.StringVar()
        ttk.Entry(frm, textvariable=self.weight_var, width=25).grid(row=1, column=1, pady=4)

        ttk.Label(frm, text="Height (m):").grid(row=2, column=0, sticky="w", pady=4)
        self.height_var = tk.StringVar()
        ttk.Entry(frm, textvariable=self.height_var, width=25).grid(row=2, column=1, pady=4)

        btns = ttk.Frame(frm)
        btns.grid(row=3, column=0, columnspan=2, pady=10)
        ttk.Button(btns, text="Calculate", command=self.calculate).pack(side="left", padx=4)
        ttk.Button(btns, text="Save record", command=self.save).pack(side="left", padx=4)
        ttk.Button(btns, text="View trend", command=self.show_graph).pack(side="left", padx=4)

        self.result = tk.Label(frm, text="Enter values and press Calculate",
                               font=("Helvetica", 14, "bold"), width=32, height=3,
                               bg="#EEEEEE", fg="black")
        self.result.grid(row=4, column=0, columnspan=2, pady=10)
        self.last = None  # (weight, height, bmi, category)

        ttk.Label(frm, text="Ranges: <18.5 Underweight | 18.5-24.9 Normal | "
                            "25-29.9 Overweight | 30+ Obese",
                  font=("Helvetica", 8), wraplength=380).grid(row=5, column=0, columnspan=2)

    def _refresh_users(self):
        if not self.db:
            return
        try:
            self.user_box["values"] = self.db.users()
        except sqlite3.Error as err:
            messagebox.showerror("Database error", f"Could not read users:\n{err}")

    def calculate(self):
        try:
            w = parse_positive(self.weight_var.get(), "Weight")
            h = parse_positive(self.height_var.get(), "Height")
            if h > 3:
                raise ValueError("Height looks too large - please enter metres (e.g. 1.75).")
        except ValueError as err:
            self.result.config(text=str(err), bg="#FFCDD2", fg="black", font=("Helvetica", 10, "bold"))
            self.last = None
            return None
        bmi = calculate_bmi(w, h)
        cat, colour = classify(bmi)
        self.result.config(text=f"BMI: {bmi:.2f}\n{cat}", bg=colour, fg="white",
                           font=("Helvetica", 14, "bold"))
        self.last = (w, h, bmi, cat)
        return self.last

    def save(self):
        name = self.user_var.get().strip()
        if not name:
            messagebox.showwarning("Missing name", "Please enter a user name to save a record.")
            return
        if not self.calculate():
            return
        if not self.db:
            messagebox.showerror("Database error", "Database is unavailable.")
            return
        w, h, bmi, cat = self.last
        try:
            self.db.add_record(name, w, h, round(bmi, 2), cat)
        except sqlite3.Error as err:
            messagebox.showerror("Database error", f"Could not save record:\n{err}")
            return
        self._refresh_users()
        messagebox.showinfo("Saved", f"Record saved for {name}.")

    def show_graph(self):
        name = self.user_var.get().strip()
        if not name:
            messagebox.showwarning("Missing name", "Select or type a user name first.")
            return
        if not HAVE_MPL:
            messagebox.showerror("matplotlib missing", "Install it with: pip install matplotlib")
            return
        try:
            rows = self.db.history(name) if self.db else []
        except sqlite3.Error as err:
            messagebox.showerror("Database error", f"Could not read history:\n{err}")
            return
        if not rows:
            messagebox.showinfo("No data", f"No records found for '{name}'.")
            return
        from datetime import datetime
        dates = [datetime.fromisoformat(r[0]) for r in rows]
        values = [r[3] for r in rows]

        win = tk.Toplevel(self)
        win.title(f"BMI trend - {name}")
        fig = Figure(figsize=(6.5, 4), dpi=100)
        ax = fig.add_subplot(111)
        ax.axhspan(0, 18.5, color="#2196F3", alpha=0.12)
        ax.axhspan(18.5, 25, color="#4CAF50", alpha=0.12)
        ax.axhspan(25, 30, color="#FF9800", alpha=0.12)
        ax.axhspan(30, 60, color="#F44336", alpha=0.12)
        ax.plot(dates, values, marker="o", color="black")
        ax.set_ylim(min(15, min(values) - 2), max(35, max(values) + 2))
        ax.set_title(f"BMI over time - {name}")
        ax.set_xlabel("Date")
        ax.set_ylabel("BMI")
        fig.autofmt_xdate()
        canvas = FigureCanvasTkAgg(fig, master=win)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)


if __name__ == "__main__":
    BMIApp().mainloop()
