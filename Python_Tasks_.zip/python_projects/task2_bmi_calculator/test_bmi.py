import os, tempfile, unittest
from bmi_core import parse_positive, calculate_bmi, classify, BMIDatabase


class TestBMI(unittest.TestCase):
    def test_formula(self):
        self.assertAlmostEqual(calculate_bmi(70, 1.75), 22.857, places=3)

    def test_categories(self):
        self.assertEqual(classify(18.49)[0], "Underweight")
        self.assertEqual(classify(18.5)[0], "Normal")
        self.assertEqual(classify(24.99)[0], "Normal")
        self.assertEqual(classify(25)[0], "Overweight")
        self.assertEqual(classify(29.99)[0], "Overweight")
        self.assertEqual(classify(30)[0], "Obese")

    def test_validation(self):
        for bad in ["", "abc", "-5", "0", "nan", "inf"]:
            with self.assertRaises(ValueError):
                parse_positive(bad, "X")
        self.assertEqual(parse_positive(" 70.5 ", "X"), 70.5)

    def test_db(self):
        with tempfile.TemporaryDirectory() as d:
            db = BMIDatabase(os.path.join(d, "t.db"))
            db.add_record("alice", 70, 1.75, 22.86, "Normal", "2024-01-01T10:00:00")
            db.add_record("alice", 72, 1.75, 23.51, "Normal", "2024-02-01T10:00:00")
            db.add_record("bob", 90, 1.7, 31.14, "Obese")
            self.assertEqual(db.users(), ["alice", "bob"])
            self.assertEqual(len(db.history("alice")), 2)


if __name__ == "__main__":
    unittest.main()
