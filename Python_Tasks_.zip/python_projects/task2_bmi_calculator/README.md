# BMI Calculator

A simple Python program for calculating Body Mass Index (BMI) from weight and height. It includes a command-line version and a desktop app.

## What it can do
- Calculate BMI using kilograms and metres.
- Show a general BMI category.
- Save and view previous calculations in the desktop version.
- Store records locally using SQLite.

## Requirements
- Python 3.10 or newer.
- Tkinter and SQLite (normally included with Python on Windows).
- Matplotlib for the chart in the desktop app.

## Run it
Open Command Prompt in this folder:

```bash
python -m pip install -r requirements.txt
python bmi_cli.py
```

To open the desktop app:

```bash
python bmi_gui.py
```

## Tests
```bash
python -m unittest -v
```

For more details, see `DOCUMENTATION.md`. BMI is a general screening measure, not a medical diagnosis.
