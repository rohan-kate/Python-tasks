"""BMI Calculator - Beginner tier (command line)."""
from bmi_core import parse_positive, calculate_bmi, classify


def ask(prompt, name):
    while True:
        try:
            return parse_positive(input(prompt), name)
        except ValueError as err:
            print(f"  Error: {err}")


def main():
    print("=== BMI Calculator ===")
    while True:
        weight = ask("Enter your weight in kg: ", "Weight")
        height = ask("Enter your height in metres (e.g. 1.75): ", "Height")
        if height > 3:
            print("  Hint: height looks too large - did you enter centimetres? Use metres.")
            continue
        bmi = calculate_bmi(weight, height)
        category, _ = classify(bmi)
        print(f"\nYour BMI is {bmi:.2f} -> {category}\n")
        if input("Calculate again? (y/n): ").strip().lower() != "y":
            break
    print("Goodbye!")


if __name__ == "__main__":
    main()
