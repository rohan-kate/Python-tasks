# BMI Calculator

## About the project
The BMI Calculator is a small Python project that calculates Body Mass Index using a person's weight and height. It shows the BMI value and gives a general category such as Underweight, Normal, Overweight or Obese. The project includes a simple command-line version and a desktop version.

## Main features
- Calculate BMI using weight in kilograms and height in metres.
- Check the BMI category and display the result.
- Enter values again to calculate another result.
- The GUI version can save records in a local SQLite database and show previous entries.
- Input checks help prevent empty, invalid or non-positive values.

## Files in this folder
- `bmi_cli.py` – command-line version.
- `bmi_gui.py` – desktop application built with Tkinter.
- `bmi_core.py` – shared BMI calculation and database functions.
- `test_bmi.py` – automated tests.
- `requirements.txt` – additional package required for the chart.

## Requirements
Install Python 3.10 or later. Tkinter and SQLite are included with most standard Windows Python installations. The GUI chart uses Matplotlib.

## How to run
Open Command Prompt in this folder and run:

```bash
python -m pip install -r requirements.txt
python bmi_cli.py
```

To open the desktop version, run:

```bash
python bmi_gui.py
```

## Run the tests
```bash
python -m unittest -v
```

## Note
The BMI result is only a general screening guide. It is not a medical diagnosis. Use height in metres (for example, `1.75`) and weight in kilograms.
