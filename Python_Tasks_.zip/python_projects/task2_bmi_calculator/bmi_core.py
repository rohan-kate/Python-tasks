"""Core BMI logic + SQLite storage (shared by the CLI and GUI versions)."""
import sqlite3
from datetime import datetime

CATEGORIES = [
    (18.5, "Underweight", "#2196F3"),
    (25.0, "Normal", "#4CAF50"),
    (30.0, "Overweight", "#FF9800"),
    (float("inf"), "Obese", "#F44336"),
]


def parse_positive(text, name):
    """Convert text to a positive float or raise ValueError with a helpful message."""
    text = (text or "").strip()
    if not text:
        raise ValueError(f"{name} cannot be empty.")
    try:
        value = float(text)
    except ValueError:
        raise ValueError(f"{name} must be a number (e.g. 70 or 1.75), not '{text}'.")
    if value != value or value in (float("inf"), float("-inf")):
        raise ValueError(f"{name} must be a real number.")
    if value <= 0:
        raise ValueError(f"{name} must be greater than zero.")
    return value


def calculate_bmi(weight_kg, height_m):
    if weight_kg <= 0 or height_m <= 0:
        raise ValueError("Weight and height must be positive.")
    return weight_kg / (height_m ** 2)


def classify(bmi):
    """Return (category_name, colour_hex). Uses the unrounded value."""
    for upper, name, colour in CATEGORIES:
        if bmi < upper:
            return name, colour
    return "Obese", "#F44336"


class BMIDatabase:
    """SQLite storage for multi-user BMI records."""

    def __init__(self, path="bmi_records.db"):
        self.path = path
        self._init()

    def _connect(self):
        return sqlite3.connect(self.path)

    def _init(self):
        with self._connect() as conn:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS records (
                       id INTEGER PRIMARY KEY AUTOINCREMENT,
                       username TEXT NOT NULL,
                       weight REAL NOT NULL,
                       height REAL NOT NULL,
                       bmi REAL NOT NULL,
                       category TEXT NOT NULL,
                       recorded_at TEXT NOT NULL)"""
            )

    def add_record(self, username, weight, height, bmi, category, when=None):
        when = when or datetime.now().isoformat(timespec="seconds")
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO records (username, weight, height, bmi, category, recorded_at) "
                "VALUES (?,?,?,?,?,?)",
                (username, weight, height, bmi, category, when),
            )

    def users(self):
        with self._connect() as conn:
            rows = conn.execute("SELECT DISTINCT username FROM records ORDER BY username").fetchall()
        return [r[0] for r in rows]

    def history(self, username):
        with self._connect() as conn:
            return conn.execute(
                "SELECT recorded_at, weight, height, bmi, category FROM records "
                "WHERE username = ? ORDER BY recorded_at", (username,)
            ).fetchall()

    def delete_user(self, username):
        with self._connect() as conn:
            conn.execute("DELETE FROM records WHERE username = ?", (username,))
