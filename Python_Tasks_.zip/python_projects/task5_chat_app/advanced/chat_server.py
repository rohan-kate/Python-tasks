"""Chat - Advanced tier: multi-room TCP chat server with accounts and history.

Protocol: one JSON object per line (UTF-8) over TCP.
Run:  python chat_server.py [--host 127.0.0.1] [--port 5566] [--db chat.db]
"""
import argparse
import hashlib
import hmac
import json
import os
import re
import socket
import sqlite3
import threading
from datetime import datetime

MAX_LINE = 8192
MAX_MSG = 1000
HISTORY_LIMIT = 50
PBKDF2_ROUNDS = 200_000
USERNAME_RE = re.compile(r"[A-Za-z0-9_]{3,20}")
ROOM_RE = re.compile(r"[A-Za-z0-9_\-]{1,30}")


class Database:
    """Thread-safe SQLite wrapper (one short-lived connection per operation)."""

    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()
        with self._conn() as c:
            c.executescript("""
                CREATE TABLE IF NOT EXISTS users (
                    username TEXT PRIMARY KEY COLLATE NOCASE, salt BLOB NOT NULL, pw_hash BLOB NOT NULL);
                CREATE TABLE IF NOT EXISTS rooms (name TEXT PRIMARY KEY COLLATE NOCASE);
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, room TEXT NOT NULL COLLATE NOCASE,
                    username TEXT NOT NULL, text TEXT NOT NULL, ts TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS idx_msg_room ON messages(room, id);
                INSERT OR IGNORE INTO rooms(name) VALUES ('general');
            """)

    def _conn(self):
        return sqlite3.connect(self.path)

    @staticmethod
    def _hash(password, salt):
        return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ROUNDS)

    def register(self, username, password):
        salt = os.urandom(16)
        try:
            with self.lock, self._conn() as c:
                c.execute("INSERT INTO users VALUES (?,?,?)", (username, salt, self._hash(password, salt)))
            return True
        except sqlite3.IntegrityError:
            return False

    def verify(self, username, password):
        with self.lock, self._conn() as c:
            row = c.execute("SELECT username, salt, pw_hash FROM users WHERE username=?", (username,)).fetchone()
        if not row:
            self._hash(password, b"0" * 16)    # keep timing similar for unknown users
            return None
        ok = hmac.compare_digest(self._hash(password, row[1]), row[2])
        return row[0] if ok else None          # canonical capitalisation

    def ensure_room(self, room):
        with self.lock, self._conn() as c:
            c.execute("INSERT OR IGNORE INTO rooms(name) VALUES (?)", (room,))
            return c.execute("SELECT name FROM rooms WHERE name=?", (room,)).fetchone()[0]

    def rooms(self):
        with self.lock, self._conn() as c:
            return [r[0] for r in c.execute("SELECT name FROM rooms ORDER BY name")]

    def add_message(self, room, username, text, ts):
        with self.lock, self._conn() as c:
            c.execute("INSERT INTO messages(room, username, text, ts) VALUES (?,?,?,?)",
                      (room, username, text, ts))

    def history(self, room):
        with self.lock, self._conn() as c:
            rows = c.execute("SELECT username, text, ts FROM messages WHERE room=? "
                             "ORDER BY id DESC LIMIT ?", (room, HISTORY_LIMIT)).fetchall()
        return [{"user": u, "text": t, "ts": ts} for u, t, ts in reversed(rows)]


class Client:
    def __init__(self, sock):
        self.sock = sock
        self.username = None
        self.room = None
        self.send_lock = threading.Lock()

    def send(self, obj):
        data = (json.dumps(obj) + "\n").encode("utf-8")
        try:
            with self.send_lock:
                self.sock.sendall(data)
        except OSError:
            pass


class ChatServer:
    def __init__(self, host="127.0.0.1", port=5566, db_path="chat.db"):
        self.host, self.port = host, port
        self.db = Database(db_path)
        self.clients = set()
        self.lock = threading.Lock()
        self.sock = None
        self._stop = threading.Event()

    # ----- lifecycle -----
    def start(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((self.host, self.port))
        self.port = self.sock.getsockname()[1]
        self.sock.listen(20)
        threading.Thread(target=self._accept_loop, daemon=True).start()

    def stop(self):
        self._stop.set()
        if self.sock:
            self.sock.close()
        with self.lock:
            for c in list(self.clients):
                try:
                    c.sock.shutdown(socket.SHUT_RDWR)
                    c.sock.close()
                except OSError:
                    pass

    def _accept_loop(self):
        while not self._stop.is_set():
            try:
                conn, _ = self.sock.accept()
            except OSError:
                break
            threading.Thread(target=self._serve, args=(conn,), daemon=True).start()

    # ----- helpers -----
    def broadcast(self, room, obj, exclude=None):
        with self.lock:
            targets = [c for c in self.clients if c.room == room and c is not exclude]
        for c in targets:
            c.send(obj)

    def _room_users(self, room):
        with self.lock:
            return sorted(c.username for c in self.clients if c.room == room and c.username)

    def _join(self, client, room):
        old = client.room
        if old:
            client.room = None
            self.broadcast(old, {"type": "system", "room": old, "text": f"{client.username} left the room."})
            self.broadcast(old, {"type": "users", "room": old, "users": self._room_users(old)})
        room = self.db.ensure_room(room)
        client.room = room
        client.send({"type": "joined", "room": room})
        client.send({"type": "history", "room": room, "messages": self.db.history(room)})
        self.broadcast(room, {"type": "system", "room": room, "text": f"{client.username} joined the room."},
                       exclude=client)
        self.broadcast(room, {"type": "users", "room": room, "users": self._room_users(room)})
        self._broadcast_rooms()

    def _broadcast_rooms(self):
        rooms = self.db.rooms()
        with self.lock:
            targets = [c for c in self.clients if c.username]
        for c in targets:
            c.send({"type": "rooms", "rooms": rooms})

    # ----- per-connection handler -----
    def _serve(self, conn):
        client = Client(conn)
        with self.lock:
            self.clients.add(client)
        reader = conn.makefile("rb")
        try:
            while True:
                raw = reader.readline(MAX_LINE + 1)
                if not raw:
                    break
                if len(raw) > MAX_LINE:
                    client.send({"type": "error", "message": "Message too large."})
                    break
                try:
                    msg = json.loads(raw.decode("utf-8"))
                    if not isinstance(msg, dict):
                        raise ValueError
                except (ValueError, UnicodeDecodeError):
                    client.send({"type": "error", "message": "Malformed request."})
                    continue
                try:
                    self._dispatch(client, msg)
                except sqlite3.Error:
                    client.send({"type": "error", "message": "Server database error. Try again later."})
        except (OSError, ConnectionError):
            pass
        finally:
            with self.lock:
                self.clients.discard(client)
            if client.room and client.username:
                room = client.room
                self.broadcast(room, {"type": "system", "room": room, "text": f"{client.username} disconnected."})
                self.broadcast(room, {"type": "users", "room": room, "users": self._room_users(room)})
            try:
                conn.close()
            except OSError:
                pass

    def _dispatch(self, client, msg):
        kind = msg.get("type")
        if kind in ("register", "login"):
            return self._auth(client, kind, msg)
        if not client.username:
            return client.send({"type": "error", "message": "Please log in first."})
        if kind == "join":
            room = str(msg.get("room", "")).strip()
            if not ROOM_RE.fullmatch(room):
                return client.send({"type": "error",
                                    "message": "Room names: 1-30 letters, digits, '-' or '_'."})
            if client.room and client.room.lower() == room.lower():
                return
            self._join(client, room)
        elif kind == "msg":
            text = str(msg.get("text", "")).strip()
            if not client.room:
                return client.send({"type": "error", "message": "Join a room first."})
            if not text:
                return
            text = text[:MAX_MSG]
            ts = datetime.now().isoformat(timespec="seconds")
            self.db.add_message(client.room, client.username, text, ts)
            self.broadcast(client.room, {"type": "msg", "room": client.room,
                                         "user": client.username, "text": text, "ts": ts})
        elif kind == "rooms":
            client.send({"type": "rooms", "rooms": self.db.rooms()})
        else:
            client.send({"type": "error", "message": f"Unknown request type: {kind!r}"})

    def _auth(self, client, kind, msg):
        if client.username:
            return client.send({"type": "error", "message": "Already logged in."})
        username = str(msg.get("username", "")).strip()
        password = str(msg.get("password", ""))
        if not USERNAME_RE.fullmatch(username):
            return client.send({"type": "auth_error",
                                "message": "Username must be 3-20 letters, digits or underscores."})
        if kind == "register":
            if len(password) < 6:
                return client.send({"type": "auth_error", "message": "Password must be at least 6 characters."})
            if not self.db.register(username, password):
                return client.send({"type": "auth_error", "message": "That username is already taken."})
            canonical = username
        else:
            canonical = self.db.verify(username, password)
            if not canonical:
                return client.send({"type": "auth_error", "message": "Invalid username or password."})
        with self.lock:
            if any(c.username and c.username.lower() == canonical.lower() for c in self.clients):
                return client.send({"type": "auth_error", "message": "That user is already logged in."})
            client.username = canonical
        client.send({"type": "auth_ok", "username": canonical})
        client.send({"type": "rooms", "rooms": self.db.rooms()})
        self._join(client, "general")


def main():
    p = argparse.ArgumentParser(description="Advanced chat server")
    p.add_argument("--host", default="127.0.0.1", help="use 0.0.0.0 to accept LAN connections")
    p.add_argument("--port", type=int, default=5566)
    p.add_argument("--db", default="chat.db")
    a = p.parse_args()
    server = ChatServer(a.host, a.port, a.db)
    server.start()
    print(f"Chat server listening on {a.host}:{server.port} (Ctrl+C to stop)")
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        print("\nShutting down.")
        server.stop()


if __name__ == "__main__":
    main()
