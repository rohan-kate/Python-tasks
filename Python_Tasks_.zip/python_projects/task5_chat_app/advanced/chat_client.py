"""Chat - Advanced tier: tkinter GUI client (login, rooms, history, notifications, emoji)."""
import queue
import tkinter as tk
from datetime import datetime
from tkinter import ttk, messagebox

from chat_net import ChatConnection
from emoji_map import render_emoji

try:                                  # optional desktop notifications
    from plyer import notification as _plyer_notification
except Exception:
    _plyer_notification = None


class ChatApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Chat")
        self.geometry("760x520")
        self.conn = None
        self.username = None
        self.current_room = None
        self.unread = 0
        self.bind("<FocusIn>", self._on_focus)
        self.protocol("WM_DELETE_WINDOW", self._quit)
        self._login_screen()
        self.after(100, self._poll)

    # ------------- login screen -------------
    def _login_screen(self):
        self.title("Chat - Login")
        self.login = ttk.Frame(self, padding=30)
        self.login.pack(expand=True)
        self.host_var = tk.StringVar(value="127.0.0.1")
        self.port_var = tk.StringVar(value="5566")
        self.user_var = tk.StringVar()
        self.pass_var = tk.StringVar()
        for r, (label, var, show) in enumerate([("Server host", self.host_var, ""),
                                                ("Port", self.port_var, ""),
                                                ("Username", self.user_var, ""),
                                                ("Password", self.pass_var, "*")]):
            ttk.Label(self.login, text=label).grid(row=r, column=0, sticky="w", pady=4)
            e = ttk.Entry(self.login, textvariable=var, show=show, width=26)
            e.grid(row=r, column=1, pady=4, padx=8)
            if label == "Password":
                e.bind("<Return>", lambda ev: self._auth("login"))
        btns = ttk.Frame(self.login)
        btns.grid(row=4, column=0, columnspan=2, pady=10)
        ttk.Button(btns, text="Log in", command=lambda: self._auth("login")).pack(side="left", padx=5)
        ttk.Button(btns, text="Register", command=lambda: self._auth("register")).pack(side="left", padx=5)
        self.login_msg = ttk.Label(self.login, text="", foreground="#C62828", wraplength=300)
        self.login_msg.grid(row=5, column=0, columnspan=2)

    def _auth(self, kind):
        try:
            port = int(self.port_var.get())
        except ValueError:
            self.login_msg.config(text="Port must be a number.")
            return
        username, password = self.user_var.get().strip(), self.pass_var.get()
        if not username or not password:
            self.login_msg.config(text="Enter a username and password.")
            return
        self.conn and self.conn.close()
        self.conn = ChatConnection()
        try:
            self.conn.connect(self.host_var.get().strip(), port)
        except OSError as err:
            self.login_msg.config(text=f"Cannot connect: {err}")
            self.conn = None
            return
        self.conn.send({"type": kind, "username": username, "password": password})

    # ------------- chat screen -------------
    def _chat_screen(self):
        self.login.destroy()
        self.title(f"Chat - {self.username}")
        main = ttk.Frame(self, padding=8)
        main.pack(fill="both", expand=True)

        side = ttk.Frame(main)
        side.pack(side="left", fill="y")
        ttk.Label(side, text="Rooms", font=("Helvetica", 10, "bold")).pack(anchor="w")
        self.room_list = tk.Listbox(side, width=18, height=12, exportselection=False)
        self.room_list.pack(fill="y")
        self.room_list.bind("<<ListboxSelect>>", self._room_selected)
        self.new_room = tk.StringVar()
        ttk.Entry(side, textvariable=self.new_room, width=18).pack(pady=(8, 2))
        ttk.Button(side, text="Create / join room", command=self._join_typed).pack()
        ttk.Label(side, text="Online here", font=("Helvetica", 10, "bold")).pack(anchor="w", pady=(10, 0))
        self.user_list = tk.Listbox(side, width=18, height=6)
        self.user_list.pack(fill="y")

        right = ttk.Frame(main)
        right.pack(side="left", fill="both", expand=True, padx=(8, 0))
        self.room_lbl = ttk.Label(right, text="", font=("Helvetica", 12, "bold"))
        self.room_lbl.pack(anchor="w")
        box = ttk.Frame(right)
        box.pack(fill="both", expand=True)
        self.text = tk.Text(box, state="disabled", wrap="word", font=("Helvetica", 11))
        sb = ttk.Scrollbar(box, command=self.text.yview)
        self.text.config(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.text.pack(side="left", fill="both", expand=True)
        self.text.tag_config("time", foreground="#888888")
        self.text.tag_config("me", foreground="#1565C0", font=("Helvetica", 11, "bold"))
        self.text.tag_config("other", foreground="#2E7D32", font=("Helvetica", 11, "bold"))
        self.text.tag_config("system", foreground="#9E9E9E", font=("Helvetica", 10, "italic"))

        bottom = ttk.Frame(right)
        bottom.pack(fill="x", pady=(6, 0))
        self.msg_var = tk.StringVar()
        entry = ttk.Entry(bottom, textvariable=self.msg_var)
        entry.pack(side="left", fill="x", expand=True)
        entry.bind("<Return>", lambda e: self._send())
        entry.focus_set()
        ttk.Button(bottom, text="Send", command=self._send).pack(side="left", padx=(6, 0))
        ttk.Label(right, text="Tip: type :smile: :fire: :thumbsup: for emoji",
                  font=("Helvetica", 8)).pack(anchor="w")

    def _append(self, text, tag=None, time_str=None):
        self.text.config(state="normal")
        if time_str:
            self.text.insert("end", f"[{time_str}] ", "time")
        self.text.insert("end", text, tag)
        self.text.config(state="disabled")
        self.text.see("end")

    def _clear(self):
        self.text.config(state="normal")
        self.text.delete("1.0", "end")
        self.text.config(state="disabled")

    @staticmethod
    def _hhmm(ts):
        try:
            return datetime.fromisoformat(ts).strftime("%H:%M")
        except (ValueError, TypeError):
            return "--:--"

    def _show_message(self, m):
        mine = m["user"] == self.username
        self._append(f"{m['user']}: ", "me" if mine else "other", self._hhmm(m["ts"]))
        self._append(render_emoji(m["text"]) + "\n")

    # ------------- actions -------------
    def _send(self):
        text = self.msg_var.get().strip()
        if text and self.conn:
            try:
                self.conn.send({"type": "msg", "text": text})
            except OSError:
                self._append("Connection lost.\n", "system")
            self.msg_var.set("")

    def _join_typed(self):
        room = self.new_room.get().strip()
        if room:
            self.conn.send({"type": "join", "room": room})
            self.new_room.set("")

    def _room_selected(self, _event):
        sel = self.room_list.curselection()
        if sel:
            room = self.room_list.get(sel[0])
            if room != self.current_room:
                self.conn.send({"type": "join", "room": room})

    # ------------- incoming messages -------------
    def _poll(self):
        if self.conn:
            incoming = self.conn.incoming      # keep a reference: _handle may reset self.conn
            try:
                while True:
                    self._handle(incoming.get_nowait())
            except queue.Empty:
                pass
        self.after(100, self._poll)

    def _handle(self, m):
        t = m.get("type")
        if t == "auth_error":
            self.login_msg.config(text=m["message"])
            self.conn.close()
            self.conn = None
        elif t == "auth_ok":
            self.username = m["username"]
            self._chat_screen()
        elif t == "disconnected":
            if self.username:
                self._append("Disconnected from server.\n", "system")
            self.conn = None
            return
        elif not self.username:
            return
        elif t == "error":
            self._append(f"Error: {m['message']}\n", "system")
        elif t == "rooms":
            self.room_list.delete(0, "end")
            for r in m["rooms"]:
                self.room_list.insert("end", r)
                if r == self.current_room:
                    self.room_list.selection_set("end")
        elif t == "joined":
            self.current_room = m["room"]
            self.room_lbl.config(text=f"# {m['room']}")
            self._clear()
        elif t == "history":
            if m["messages"]:
                self._append("--- earlier messages ---\n", "system")
                for old in m["messages"]:
                    self._show_message(old)
                self._append("--- end of history ---\n", "system")
        elif t == "users":
            self.user_list.delete(0, "end")
            for u in m["users"]:
                self.user_list.insert("end", u)
        elif t == "system":
            self._append(m["text"] + "\n", "system")
        elif t == "msg":
            self._show_message(m)
            if m["user"] != self.username:
                self._notify(m)

    # ------------- notifications -------------
    def _is_focused(self):
        return self.focus_displayof() is not None

    def _notify(self, m):
        if self._is_focused():
            return
        self.unread += 1
        self.title(f"({self.unread}) New message - {self.username}")
        self.bell()
        if _plyer_notification:
            try:
                _plyer_notification.notify(title=f"{m['user']} in #{m['room']}",
                                           message=render_emoji(m["text"])[:100], timeout=5)
            except Exception:
                pass

    def _on_focus(self, _event):
        if self.unread and self.username:
            self.unread = 0
            self.title(f"Chat - {self.username}")

    def _quit(self):
        if self.conn:
            self.conn.close()
        self.destroy()


if __name__ == "__main__":
    ChatApp().mainloop()
