"""Network layer for the GUI client (kept separate from tkinter so it can be tested)."""
import json
import queue
import socket
import threading


class ChatConnection:
    """Connects to the server; received messages (dicts) are put on `self.incoming`."""

    def __init__(self):
        self.sock = None
        self.incoming = queue.Queue()
        self._lock = threading.Lock()

    def connect(self, host, port, timeout=5):
        self.sock = socket.create_connection((host, port), timeout=timeout)
        self.sock.settimeout(None)
        threading.Thread(target=self._reader, daemon=True).start()

    def _reader(self):
        try:
            for line in self.sock.makefile("rb"):
                try:
                    self.incoming.put(json.loads(line.decode("utf-8")))
                except ValueError:
                    continue
        except OSError:
            pass
        self.incoming.put({"type": "disconnected"})

    def send(self, obj):
        data = (json.dumps(obj) + "\n").encode("utf-8")
        with self._lock:
            self.sock.sendall(data)

    def close(self):
        try:
            # shutdown() is required: the reader thread's makefile() keeps the fd open,
            # so close() alone would not tell the server we have left.
            self.sock.shutdown(socket.SHUT_RDWR)
        except (OSError, AttributeError):
            pass
        try:
            self.sock.close()
        except (OSError, AttributeError):
            pass
