import os, queue, tempfile, time, unittest

from chat_net import ChatConnection
from chat_server import ChatServer
from emoji_map import render_emoji


def wait_for(conn, kind, timeout=3, **match):
    """Return the first incoming message of the given type (and matching fields)."""
    end = time.time() + timeout
    while time.time() < end:
        try:
            m = conn.incoming.get(timeout=0.2)
        except queue.Empty:
            continue
        if m.get("type") == kind and all(m.get(k) == v for k, v in match.items()):
            return m
    raise AssertionError(f"timed out waiting for {kind} {match}")


class TestChat(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.server = ChatServer("127.0.0.1", 0, os.path.join(self.tmp.name, "t.db"))
        self.server.start()
        self.conns = []

    def tearDown(self):
        for c in self.conns:
            c.close()
        self.server.stop()
        time.sleep(0.3)
        self.tmp.cleanup()

    def client(self, kind, user, pw="secret1"):
        c = ChatConnection()
        c.connect("127.0.0.1", self.server.port)
        self.conns.append(c)
        c.send({"type": kind, "username": user, "password": pw})
        return c

    def test_register_login_errors(self):
        a = self.client("register", "alice")
        wait_for(a, "auth_ok"); wait_for(a, "joined")
        self.assertEqual(self.server.db.verify("ALICE", "secret1"), "alice")   # case-insensitive
        self.assertIsNone(self.server.db.verify("alice", "wrong"))
        dup = self.client("register", "alice")
        self.assertIn("taken", wait_for(dup, "auth_error")["message"])
        bad = self.client("login", "alice", "nope")
        wait_for(bad, "auth_error")
        short = self.client("register", "bob", "123")
        wait_for(short, "auth_error")
        badname = self.client("register", "x y!", "secret1")
        wait_for(badname, "auth_error")

    def test_password_not_stored_plaintext(self):
        carol = self.client("register", "carol", "hunter22")
        wait_for(carol, "auth_ok"); wait_for(carol, "joined")
        import sqlite3
        raw = sqlite3.connect(self.server.db.path).execute("SELECT salt, pw_hash FROM users").fetchall()
        self.assertNotIn(b"hunter22", raw[0][0] + raw[0][1])

    def test_messaging_rooms_history(self):
        a = self.client("register", "alice")
        wait_for(a, "auth_ok"); wait_for(a, "joined", room="general")
        b = self.client("register", "bob")
        wait_for(b, "auth_ok"); wait_for(b, "joined", room="general")
        wait_for(a, "system")                                  # "bob joined"
        a.send({"type": "msg", "text": "hello :smile:"})
        m = wait_for(b, "msg")
        self.assertEqual((m["user"], m["text"]), ("alice", "hello :smile:"))
        wait_for(a, "msg")                                     # sender gets echo too

        # new room, isolation
        b.send({"type": "join", "room": "python"})
        wait_for(b, "joined", room="python")
        a.send({"type": "msg", "text": "only general"})
        b.send({"type": "msg", "text": "hi python room"})
        wait_for(b, "msg", text="hi python room")
        with self.assertRaises(AssertionError):
            wait_for(b, "msg", timeout=0.6, text="only general")

        # history loads for a late joiner
        c = self.client("register", "carol")
        h = wait_for(c, "history", room="general")
        texts = [x["text"] for x in h["messages"]]
        self.assertEqual(texts, ["hello :smile:", "only general"])
        wait_for(c, "users")

        # bad room name + unauthenticated use
        a.send({"type": "join", "room": "bad room!"})
        wait_for(a, "error")
        raw = ChatConnection(); raw.connect("127.0.0.1", self.server.port); self.conns.append(raw)
        raw.send({"type": "msg", "text": "hi"})
        wait_for(raw, "error")

    def test_disconnect_notice_and_duplicate_login(self):
        a = self.client("register", "alice"); wait_for(a, "auth_ok"); wait_for(a, "joined")
        b = self.client("register", "bob"); wait_for(b, "auth_ok"); wait_for(b, "joined")
        dup = self.client("login", "bob"); 
        self.assertIn("already logged in", wait_for(dup, "auth_error")["message"])
        b.close()
        wait_for(a, "system", text="bob disconnected.")

    def test_emoji(self):
        self.assertEqual(render_emoji("hi :smile: :nope:"), "hi \U0001F604 :nope:")


if __name__ == "__main__":
    unittest.main()
