"""Emoji shortcode rendering, e.g. ':smile:' -> the smiling-face emoji."""
import re

EMOJI = {
    "smile": "\U0001F604", "grin": "\U0001F601", "joy": "\U0001F602", "laughing": "\U0001F606",
    "wink": "\U0001F609", "blush": "\U0001F60A", "heart_eyes": "\U0001F60D", "sunglasses": "\U0001F60E",
    "thinking": "\U0001F914", "cry": "\U0001F622", "sob": "\U0001F62D", "angry": "\U0001F620",
    "scream": "\U0001F631", "sleeping": "\U0001F634", "neutral": "\U0001F610", "slight_smile": "\U0001F642",
    "thumbsup": "\U0001F44D", "+1": "\U0001F44D", "thumbsdown": "\U0001F44E", "-1": "\U0001F44E",
    "clap": "\U0001F44F", "wave": "\U0001F44B", "pray": "\U0001F64F", "ok_hand": "\U0001F44C",
    "muscle": "\U0001F4AA", "fire": "\U0001F525", "heart": "\u2764\ufe0f", "broken_heart": "\U0001F494",
    "star": "\u2B50", "sparkles": "\u2728", "tada": "\U0001F389", "party": "\U0001F973",
    "100": "\U0001F4AF", "check": "\u2705", "x": "\u274C", "warning": "\u26A0\ufe0f",
    "eyes": "\U0001F440", "rocket": "\U0001F680", "coffee": "\u2615", "pizza": "\U0001F355",
    "beer": "\U0001F37A", "cake": "\U0001F382", "gift": "\U0001F381", "sun": "\u2600\ufe0f",
    "moon": "\U0001F319", "rainbow": "\U0001F308", "dog": "\U0001F436", "cat": "\U0001F431",
    "bulb": "\U0001F4A1", "computer": "\U0001F4BB", "snake": "\U0001F40D", "bug": "\U0001F41B",
}
_PATTERN = re.compile(r":([a-z0-9_+\-]+):")


def render_emoji(text):
    """Replace known :shortcodes: with Unicode; unknown ones are left unchanged."""
    return _PATTERN.sub(lambda m: EMOJI.get(m.group(1), m.group(0)), text)
