# Chat Application

## About the project
The Chat Application demonstrates how two or more computers or programs can exchange messages using Python sockets. This folder contains a beginner chat and an advanced chat. The beginner version is a small two-person command-line chat. The advanced version adds a desktop interface, user accounts, chat rooms and saved message history.

## Beginner version
The `beginner` folder contains:
- `server.py` – starts the chat server and accepts up to two users.
- `client.py` – connects a user to the server and sends or receives messages.
- `test_beginner.py` – checks the basic chat flow.

To try it, open two Command Prompt windows in the `beginner` folder. In the first window, start the server:

```bash
python server.py
```

In each window, start a client:

```bash
python client.py
```

Enter a different name in each client. Type a message and press Enter. Type `quit` to leave. Stop the server with `Ctrl+C`.

## Advanced version
The `advanced` folder contains:
- `chat_server.py` – server, account handling, rooms and message storage.
- `chat_client.py` – Tkinter desktop chat interface.
- `chat_net.py` – client-side socket communication.
- `emoji_map.py` – converts supported emoji shortcodes.
- `test_chat.py` – automated tests.

Open two Command Prompt windows in the `advanced` folder. Start the server first:

```bash
python chat_server.py
```

Then start the desktop client in each window:

```bash
python chat_client.py
```

Register a username and password, or log in with an existing account. The server creates a local SQLite database (`chat.db`) to store account details and messages. Passwords are stored as salted hashes rather than plain text.

## Requirements
Install Python 3.10 or later. The project uses Python's built-in socket, threading, SQLite and Tkinter modules. The advanced client can use `plyer` for optional desktop notifications; without it, the main chat features still work.

## Run the tests
Run the beginner tests from its folder with `python -m unittest -v`. Run the advanced tests from its folder with `python -m unittest -v`.

## Note
The default server address is `127.0.0.1`, which allows testing on the same computer. For use across a network, configure the server address and firewall carefully. This example chat is intended for learning and is not a production-secure messaging service.
