import socket, subprocess, sys, time, unittest, os, re

HERE = os.path.dirname(os.path.abspath(__file__))


def connect(name):
    s = socket.create_connection(("127.0.0.1", 5555), timeout=3)
    s.sendall((name + "\n").encode())
    return s


def read_line(s):
    buf = b""
    while not buf.endswith(b"\n"):
        buf += s.recv(1)
    return buf.decode().strip()


class TestBeginner(unittest.TestCase):
    def test_two_user_chat(self):
        srv = subprocess.Popen([sys.executable, os.path.join(HERE, "server.py")],
                               stdout=subprocess.DEVNULL)
        try:
            time.sleep(0.8)
            a = connect("Alice"); self.assertIn("Waiting", read_line(a))
            b = connect("Bob"); self.assertIn("chat now", read_line(b))
            self.assertIn("Bob joined", read_line(a))
            third = connect("Eve"); self.assertIn("full", read_line(third))
            a.sendall(b"Hello\n")
            self.assertRegex(read_line(b), r"^\[\d\d:\d\d\] Alice: Hello$")
            b.sendall(b"Hi back\n")
            self.assertRegex(read_line(a), r"^\[\d\d:\d\d\] Bob: Hi back$")
            b.close()
            self.assertIn("Bob has disconnected", read_line(a))
            a.close()
        finally:
            srv.terminate()


if __name__ == "__main__":
    unittest.main()
