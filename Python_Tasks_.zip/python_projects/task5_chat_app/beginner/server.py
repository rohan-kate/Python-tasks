"""Chat - Beginner tier: two-user chat server (socket + threading).

Run first:   python server.py
Then start two clients:   python client.py   (in two terminals)
"""
import socket
import threading
from datetime import datetime

HOST, PORT = "127.0.0.1", 5555
clients = {}                 # socket -> name
lock = threading.Lock()


def stamp():
    return datetime.now().strftime("[%H:%M]")


def send(sock, text):
    try:
        sock.sendall((text + "\n").encode("utf-8"))
    except OSError:
        pass


def send_to_others(sender, text):
    with lock:
        for s in list(clients):
            if s is not sender:
                send(s, text)


def handle(conn, addr):
    reader = conn.makefile("r", encoding="utf-8", errors="replace")
    name = None
    try:
        with lock:
            full = len(clients) >= 2
        if full:
            send(conn, "Server: chat is full (2 users max). Try again later.")
            return
        name = (reader.readline().strip() or f"User{addr[1]}")[:20]
        with lock:
            clients[conn] = name
            count = len(clients)
        print(f"{stamp()} {name} connected from {addr}")
        if count == 1:
            send(conn, "Server: connected. Waiting for another user to join...")
        else:
            send(conn, "Server: connected. You can chat now!")
            send_to_others(conn, f"Server: {name} joined the chat.")
        for line in reader:
            msg = line.strip()
            if msg:
                send_to_others(conn, f"{stamp()} {name}: {msg}")
    except (ConnectionError, OSError):
        pass
    finally:
        with lock:
            was_registered = clients.pop(conn, None) is not None
        if was_registered:
            print(f"{stamp()} {name} disconnected")
            send_to_others(conn, f"Server: {name} has disconnected.")
        conn.close()


def main():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((HOST, PORT))
    srv.listen(5)
    print(f"Server listening on {HOST}:{PORT}  (Ctrl+C to stop)")
    try:
        while True:
            conn, addr = srv.accept()
            threading.Thread(target=handle, args=(conn, addr), daemon=True).start()
    except KeyboardInterrupt:
        print("\nShutting down.")
    finally:
        srv.close()


if __name__ == "__main__":
    main()
