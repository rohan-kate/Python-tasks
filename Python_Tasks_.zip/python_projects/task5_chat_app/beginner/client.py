"""Chat - Beginner tier: command-line client. Type 'quit' to leave."""
import socket
import sys
import threading

HOST, PORT = "127.0.0.1", 5555


def receive(sock):
    try:
        for line in sock.makefile("r", encoding="utf-8", errors="replace"):
            print("\r" + line.rstrip())
    except OSError:
        pass
    print("\nConnection closed.")
    # Closing stdin isn't portable; the main loop exits on next input / EOF.


def main():
    name = input("Your name: ").strip() or "Anonymous"
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect((HOST, PORT))
    except OSError as err:
        print(f"Could not connect to {HOST}:{PORT} - is the server running? ({err})")
        sys.exit(1)
    sock.sendall((name + "\n").encode("utf-8"))
    t = threading.Thread(target=receive, args=(sock,), daemon=True)
    t.start()
    print("Type a message and press Enter. Type 'quit' to exit.")
    try:
        while t.is_alive():
            msg = input()
            if msg.strip().lower() == "quit":
                break
            if msg.strip():
                sock.sendall((msg + "\n").encode("utf-8"))
    except (EOFError, KeyboardInterrupt, OSError):
        pass
    finally:
        try:
            sock.shutdown(socket.SHUT_RDWR)   # makes the server notice immediately
        except OSError:
            pass
        sock.close()
        print("Goodbye!")


if __name__ == "__main__":
    main()
