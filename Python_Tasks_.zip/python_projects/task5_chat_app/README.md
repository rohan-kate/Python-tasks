# Chat Application

This project demonstrates how Python sockets can be used to send messages between chat clients. It includes a basic command-line chat and an advanced desktop version.

## Beginner version
Open Command Prompt in the `beginner` folder. Start the server in the first window:

```bash
python server.py
```

Open another one or two windows in the same folder and start a client in each:

```bash
python client.py
```

Choose a different name in each client. Type `quit` to leave the chat. Stop the server with `Ctrl+C`.

## Advanced version
Open Command Prompt in the `advanced` folder. Start the server first:

```bash
python chat_server.py
```

Then open another window and start a client:

```bash
python chat_client.py
```

Run the client in additional windows to test multiple users. The advanced version includes a desktop interface, accounts, chat rooms and local SQLite message history.

## Requirements
- Python 3.10 or newer.
- The standard `socket`, `threading`, `sqlite3` and `tkinter` modules.
- Optional desktop notifications may need the package listed in the project code or requirements.

## Tests
Run tests from the relevant folder:

```bash
python -m unittest -v
```

For more details, see `DOCUMENTATION.md`. The default server is for local testing and this learning project is not intended for production-secure messaging.
