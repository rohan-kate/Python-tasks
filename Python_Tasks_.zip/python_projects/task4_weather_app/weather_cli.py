"""Weather App - Beginner tier (command line)."""
from weather_core import fetch_current, get_api_key, WeatherError


def show(w):
    print(f"\nWeather in {w['city']}, {w['country']}")
    print(f"  Temperature : {w['temp_c']:.1f} \u00b0C / {w['temp_f']:.1f} \u00b0F")
    print(f"  Humidity    : {w['humidity']}%")
    print(f"  Condition   : {w['description']}")
    print(f"  Wind speed  : {w['wind']:.1f} m/s")


def main():
    print("=== Weather App ===")
    api_key = get_api_key()
    if not api_key:
        api_key = input("Enter your OpenWeatherMap API key: ").strip()
    while True:
        city = input("\nEnter a city name or ZIP code (or 'q' to quit): ").strip()
        if city.lower() == "q":
            print("Goodbye!")
            break
        try:
            show(fetch_current(city, api_key))   # empty input raises WeatherError
        except WeatherError as err:
            print(f"  Error: {err}")


if __name__ == "__main__":
    main()
