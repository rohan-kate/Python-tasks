# Weather App

A Python weather lookup project with a command-line version and a desktop app. It gets weather information from the OpenWeatherMap service.

## What it can do
- Search by city name or supported ZIP code.
- Display current temperature and weather conditions.
- Show details such as humidity and wind speed.
- View forecast information in the desktop app.
- Handle common connection and search errors.

## Requirements
- Python 3.10 or newer.
- Packages listed in `requirements.txt`.
- An OpenWeatherMap API key and an internet connection.

## Set up the API key
Create an API key with OpenWeatherMap. In Windows Command Prompt, set it for the current terminal:

```bash
set OPENWEATHER_API_KEY=your_api_key_here
```

Keep your key private. Do not commit it to a public repository.

## Run it
```bash
python -m pip install -r requirements.txt
python weather_cli.py
```

To open the desktop app:

```bash
python weather_gui.py
```

## Tests
```bash
python -m unittest -v
```

For more details, see `DOCUMENTATION.md`. Weather data and API availability depend on the external service.
