"""Weather App - Advanced tier (tkinter + requests + Pillow)."""
import io
import queue
import threading
import tkinter as tk
from tkinter import ttk

import requests
from PIL import Image, ImageTk

from weather_core import (ICON_URL, TIMEOUT, WeatherError, detect_city_by_ip,
                          fetch_current, fetch_forecast, get_api_key)


class WeatherApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Weather App")
        self.geometry("720x620")
        self.api_key = get_api_key()
        self.unit = "C"
        self.data = None                  # (current, hourly, daily)
        self.icon_cache = {}
        self.images = []                  # keep references so Tk doesn't garbage-collect them
        self.q = queue.Queue()
        self._build()
        self.after(100, self._poll)
        if not self.api_key:
            self._error("No API key found. Set OPENWEATHER_API_KEY or create api_key.txt "
                        "next to this script.")

    # ---------- layout ----------
    def _build(self):
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")
        ttk.Label(top, text="City or ZIP:").pack(side="left")
        self.city_var = tk.StringVar()
        entry = ttk.Entry(top, textvariable=self.city_var, width=24)
        entry.pack(side="left", padx=6)
        entry.bind("<Return>", lambda e: self.get_weather())
        ttk.Button(top, text="Get Weather", command=self.get_weather).pack(side="left")
        ttk.Button(top, text="\u00b0C / \u00b0F", command=self.toggle_unit).pack(side="left", padx=6)
        ttk.Button(top, text="Detect my location", command=self.detect).pack(side="left")

        self.error_lbl = tk.Label(self, text="", fg="white", bg=self.cget("bg"), wraplength=680)
        self.error_lbl.pack(fill="x", padx=10)

        self.current_frame = ttk.LabelFrame(self, text="Current weather", padding=10)
        self.current_frame.pack(fill="x", padx=10, pady=6)
        self.icon_lbl = ttk.Label(self.current_frame)
        self.icon_lbl.pack(side="left", padx=10)
        self.current_lbl = ttk.Label(self.current_frame, text="Search for a city to begin.",
                                     font=("Helvetica", 12), justify="left")
        self.current_lbl.pack(side="left")

        self.hourly_frame = ttk.LabelFrame(self, text="Next 6 hours", padding=10)
        self.hourly_frame.pack(fill="x", padx=10, pady=6)
        self.daily_frame = ttk.LabelFrame(self, text="5-day forecast", padding=10)
        self.daily_frame.pack(fill="x", padx=10, pady=6)

    # ---------- actions ----------
    def _error(self, msg):
        self.error_lbl.config(text=msg, bg="#C62828" if msg else self.cget("bg"))

    def toggle_unit(self):
        self.unit = "F" if self.unit == "C" else "C"
        if self.data:
            self.render(*self.data)

    def get_weather(self):
        self._error("")
        city = self.city_var.get().strip()
        if not city:
            self._error("Please enter a city name or ZIP code.")
            return
        if not self.api_key:
            self._error("No API key configured (see README).")
            return
        self.current_lbl.config(text="Loading...")
        threading.Thread(target=self._worker, args=(city,), daemon=True).start()

    def detect(self):
        self._error("")
        self.current_lbl.config(text="Detecting location...")

        def work():
            try:
                self.q.put(("city", detect_city_by_ip()))
            except WeatherError as err:
                self.q.put(("error", str(err)))
        threading.Thread(target=work, daemon=True).start()

    def _worker(self, city):
        """Runs in a background thread so the window never freezes."""
        try:
            current = fetch_current(city, self.api_key)
            hourly, daily = fetch_forecast(city, self.api_key)
            icons = {current["icon"]} | {h["icon"] for h in hourly} | {d["icon"] for d in daily}
            images = {}
            for ic in icons:
                images[ic] = self._download_icon(ic)
            self.q.put(("data", (current, hourly, daily, images)))
        except WeatherError as err:
            self.q.put(("error", str(err)))
        except Exception as err:  # never let a thread die silently
            self.q.put(("error", f"Unexpected error: {err}"))

    def _download_icon(self, code):
        try:
            r = requests.get(ICON_URL.format(icon=code), timeout=TIMEOUT)
            r.raise_for_status()
            return Image.open(io.BytesIO(r.content)).convert("RGBA")
        except Exception:
            return None   # missing icon is not fatal

    def _poll(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "error":
                    self.current_lbl.config(text="")
                    self._error(payload)
                elif kind == "city":
                    self.city_var.set(payload)
                    self.get_weather()
                elif kind == "data":
                    current, hourly, daily, images = payload
                    self.icon_cache.update(images)
                    self.data = (current, hourly, daily)
                    self.render(current, hourly, daily)
        except queue.Empty:
            pass
        self.after(100, self._poll)

    # ---------- rendering ----------
    def _temp(self, c, f):
        return f"{c:.0f}\u00b0C" if self.unit == "C" else f"{f:.0f}\u00b0F"

    def _photo(self, code, size):
        img = self.icon_cache.get(code)
        if img is None:
            return None
        photo = ImageTk.PhotoImage(img.resize((size, size)))
        self.images.append(photo)
        return photo

    def render(self, current, hourly, daily):
        self.images.clear()
        photo = self._photo(current["icon"], 90)
        self.icon_lbl.config(image=photo or "")
        self.current_lbl.config(text=(
            f"{current['city']}, {current['country']}\n"
            f"{self._temp(current['temp_c'], current['temp_f'])}  -  {current['description']}\n"
            f"Humidity: {current['humidity']}%\n"
            f"Wind: {current['wind']:.1f} m/s"))

        for frame in (self.hourly_frame, self.daily_frame):
            for child in frame.winfo_children():
                child.destroy()
        for h in hourly:
            self._card(self.hourly_frame, h["time"].strftime("%H:%M"), h["icon"],
                       self._temp(h["temp_c"], h["temp_f"]), h["description"])
        for d in daily:
            temps = (f"{self._temp(d['min_c'], d['min_f'])} / "
                     f"{self._temp(d['max_c'], d['max_f'])}")
            self._card(self.daily_frame, d["date"].strftime("%a %d"), d["icon"], temps,
                       d["description"])

    def _card(self, parent, title, icon, temp, desc):
        card = ttk.Frame(parent, padding=4)
        card.pack(side="left", expand=True, fill="x")
        ttk.Label(card, text=title, font=("Helvetica", 10, "bold")).pack()
        photo = self._photo(icon, 48)
        if photo:
            ttk.Label(card, image=photo).pack()
        ttk.Label(card, text=temp).pack()
        ttk.Label(card, text=desc, font=("Helvetica", 8), wraplength=100).pack()


if __name__ == "__main__":
    WeatherApp().mainloop()
