import unittest
from datetime import datetime, timezone
from unittest import mock

import requests

import weather_core as wc

CURRENT = {"name": "London", "sys": {"country": "GB"}, "timezone": 0,
           "main": {"temp": 20.0, "feels_like": 19.0, "humidity": 55},
           "weather": [{"description": "partly cloudy", "icon": "02d"}], "wind": {"speed": 3.4}}


def fake_forecast():
    base = int(datetime(2024, 6, 1, 0, 0, tzinfo=timezone.utc).timestamp())
    items = [{"dt": base + i * 10800, "main": {"temp": 10 + i},
              "weather": [{"description": "clear sky", "icon": "01n"}]} for i in range(40)]
    return {"list": items, "city": {"timezone": 0}}


def resp(status, payload=None):
    m = mock.Mock(status_code=status)
    m.json.return_value = payload
    return m


class TestWeather(unittest.TestCase):
    def test_empty_input(self):
        with self.assertRaises(wc.WeatherError):
            wc.build_params("   ", "key")

    def test_zip_vs_city(self):
        self.assertIn("zip", wc.build_params("90210", "k"))
        self.assertIn("zip", wc.build_params("90210,US", "k"))
        self.assertIn("q", wc.build_params("London", "k"))
        self.assertIn("q", wc.build_params("New York", "k"))

    def test_current_ok(self):
        with mock.patch("requests.get", return_value=resp(200, CURRENT)):
            w = wc.fetch_current("London", "k")
        self.assertEqual(w["humidity"], 55)
        self.assertAlmostEqual(w["temp_f"], 68.0)
        self.assertEqual(w["description"], "Partly Cloudy")

    def test_errors(self):
        cases = [(401, "Invalid API key"), (404, "not found"), (429, "rate limit"), (500, "HTTP 500")]
        for status, text in cases:
            with mock.patch("requests.get", return_value=resp(status)):
                with self.assertRaises(wc.WeatherError) as ctx:
                    wc.fetch_current("London", "k")
                self.assertIn(text, str(ctx.exception))
        with mock.patch("requests.get", side_effect=requests.exceptions.Timeout):
            with self.assertRaises(wc.WeatherError) as ctx:
                wc.fetch_current("London", "k")
            self.assertIn("timed out", str(ctx.exception))
        with mock.patch("requests.get", side_effect=requests.exceptions.ConnectionError):
            with self.assertRaises(wc.WeatherError):
                wc.fetch_current("London", "k")

    def test_forecast(self):
        hourly, daily = wc.parse_forecast(fake_forecast())
        self.assertEqual(len(hourly), 2)          # next 6 hours
        self.assertEqual(len(daily), 5)           # next 5 days
        self.assertEqual(daily[0]["min_c"], 10)
        self.assertEqual(daily[0]["max_c"], 17)

    def test_bad_format(self):
        with self.assertRaises(wc.WeatherError):
            wc.parse_current({"oops": 1})

    def test_ip_detect(self):
        with mock.patch("requests.get", return_value=mock.Mock(json=lambda: {"city": "Pune"},
                                                               raise_for_status=lambda: None)):
            self.assertEqual(wc.detect_city_by_ip(), "Pune")


if __name__ == "__main__":
    unittest.main()
