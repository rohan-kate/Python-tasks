"""OpenWeatherMap helpers shared by the CLI and GUI versions."""
import os
import re
from collections import Counter, OrderedDict
from datetime import datetime, timedelta, timezone

import requests

BASE = "https://api.openweathermap.org/data/2.5"
ICON_URL = "https://openweathermap.org/img/wn/{icon}@2x.png"
TIMEOUT = 10
HOURLY_SLOTS = 2        # free forecast API has 3-hour steps -> 2 steps = next 6 hours
DAILY_DAYS = 5


class WeatherError(Exception):
    """Friendly error that can be shown directly to the user."""


def get_api_key():
    """Look for the key in env var OPENWEATHER_API_KEY, then in api_key.txt next to this file."""
    key = os.environ.get("OPENWEATHER_API_KEY", "").strip()
    if key:
        return key
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "api_key.txt")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            return fh.read().strip()
    return ""


def c_to_f(c):
    return c * 9 / 5 + 32


def build_params(query, api_key):
    """City name or ZIP code (optionally 'ZIP,CC', e.g. '90210,US') -> request params."""
    query = (query or "").strip()
    if not query:
        raise WeatherError("Please enter a city name or ZIP code.")
    if not api_key:
        raise WeatherError("No API key found. Set OPENWEATHER_API_KEY or put the key in api_key.txt.")
    params = {"appid": api_key, "units": "metric"}
    if re.fullmatch(r"[A-Za-z0-9\- ]{3,10}(,\s*[A-Za-z]{2})?", query) and any(c.isdigit() for c in query):
        params["zip"] = query.replace(" ", "") if "," in query else query
    else:
        params["q"] = query
    return params


def _get(endpoint, params):
    try:
        resp = requests.get(f"{BASE}/{endpoint}", params=params, timeout=TIMEOUT)
    except requests.exceptions.Timeout:
        raise WeatherError("The request timed out. Check your connection and try again.")
    except requests.exceptions.ConnectionError:
        raise WeatherError("Network error: could not reach the weather service.")
    except requests.exceptions.RequestException as err:
        raise WeatherError(f"Request failed: {err}")
    if resp.status_code == 401:
        raise WeatherError("Invalid API key. (New keys can take up to 2 hours to activate.)")
    if resp.status_code == 404:
        raise WeatherError("City or ZIP code not found. Check the spelling and try again.")
    if resp.status_code == 429:
        raise WeatherError("API rate limit reached. Wait a minute and try again.")
    if resp.status_code != 200:
        raise WeatherError(f"Weather service error (HTTP {resp.status_code}).")
    try:
        return resp.json()
    except ValueError:
        raise WeatherError("Received an unreadable response from the weather service.")


def parse_current(data):
    try:
        temp_c = float(data["main"]["temp"])
        return {
            "city": data.get("name", "Unknown"),
            "country": data.get("sys", {}).get("country", ""),
            "temp_c": temp_c,
            "temp_f": c_to_f(temp_c),
            "feels_c": float(data["main"].get("feels_like", temp_c)),
            "humidity": int(data["main"]["humidity"]),
            "description": data["weather"][0]["description"].title(),
            "icon": data["weather"][0].get("icon", "01d"),
            "wind": float(data["wind"]["speed"]),
            "tz_offset": int(data.get("timezone", 0)),
        }
    except (KeyError, IndexError, TypeError, ValueError):
        raise WeatherError("Unexpected data format from the weather service.")


def fetch_current(query, api_key):
    return parse_current(_get("weather", build_params(query, api_key)))


def parse_forecast(data, tz_offset=None):
    """Return (hourly, daily) lists from the 5-day / 3-hour forecast response."""
    try:
        if tz_offset is None:
            tz_offset = int(data.get("city", {}).get("timezone", 0))
        tz = timezone(timedelta(seconds=tz_offset))
        entries = []
        for item in data["list"]:
            entries.append({
                "time": datetime.fromtimestamp(item["dt"], tz),
                "temp_c": float(item["main"]["temp"]),
                "description": item["weather"][0]["description"].title(),
                "icon": item["weather"][0]["icon"],
            })
    except (KeyError, IndexError, TypeError, ValueError):
        raise WeatherError("Unexpected forecast format from the weather service.")

    hourly = [{**e, "temp_f": c_to_f(e["temp_c"])} for e in entries[:HOURLY_SLOTS]]

    days = OrderedDict()
    for e in entries:
        days.setdefault(e["time"].date(), []).append(e)
    daily = []
    for date, items in list(days.items())[:DAILY_DAYS]:
        lo = min(i["temp_c"] for i in items)
        hi = max(i["temp_c"] for i in items)
        common = Counter(i["description"] for i in items).most_common(1)[0][0]
        icon = next(i["icon"] for i in items if i["description"] == common)
        daily.append({"date": date, "min_c": lo, "max_c": hi, "min_f": c_to_f(lo),
                      "max_f": c_to_f(hi), "description": common, "icon": icon.replace("n", "d")})
    return hourly, daily


def fetch_forecast(query, api_key):
    return parse_forecast(_get("forecast", build_params(query, api_key)))


def detect_city_by_ip():
    """Bonus: guess the user's city from their public IP using ipinfo.io (free tier)."""
    try:
        resp = requests.get("https://ipinfo.io/json", timeout=TIMEOUT)
        resp.raise_for_status()
        city = resp.json().get("city")
    except (requests.exceptions.RequestException, ValueError):
        raise WeatherError("Could not detect your location automatically.")
    if not city:
        raise WeatherError("Location detection returned no city.")
    return city
