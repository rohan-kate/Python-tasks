# Weather App

## About the project
The Weather App lets a user search for a city or supported ZIP code and view its weather information. It includes a command-line version and a desktop version. Weather details are requested from the OpenWeatherMap service, so an internet connection and a valid API key are required.

## Main features
- Search for weather by city name or ZIP code.
- Display current temperature, weather condition, humidity and wind speed.
- Show temperature in Celsius or Fahrenheit in the desktop app.
- The desktop version includes forecast information and an option to detect an approximate location using the network.
- Display helpful messages for missing API keys, network problems and invalid searches.

## Files in this folder
- `weather_cli.py` – command-line version.
- `weather_gui.py` – desktop application.
- `weather_core.py` – API requests and weather-data processing.
- `test_weather.py` – automated tests.
- `requirements.txt` – required third-party packages.

## Requirements and API key
Install Python 3.10 or later and create a free API key through the OpenWeatherMap website. Install the packages with:

```bash
python -m pip install -r requirements.txt
```

Set the API key before starting the app. In Windows Command Prompt, use:

```bash
set OPENWEATHER_API_KEY=your_api_key_here
```

You can also place the key in a file named `api_key.txt` beside `weather_core.py`. Keep this file private and do not upload it to GitHub.

## How to run
Run the command-line version:

```bash
python weather_cli.py
```

Run the desktop version:

```bash
python weather_gui.py
```

## Run the tests
```bash
python -m unittest -v
```

## Note
Weather information comes from an external service and may be delayed or unavailable. API usage limits and account rules are controlled by OpenWeatherMap.
