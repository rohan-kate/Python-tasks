# Random Password Generator

This project creates random passwords based on the length and character types selected by the user. It includes a command-line tool and a desktop interface.

## What it can do
- Set the password length.
- Choose uppercase letters, lowercase letters, numbers and symbols.
- Avoid characters that look similar.
- Show a basic password-strength estimate.
- Copy a generated password from the desktop app when clipboard support is available.

The generator uses Python's `secrets` module for secure random selection.

## Requirements
- Python 3.10 or newer.
- Tkinter (normally included with Python on Windows).
- Optional clipboard support through the package listed in `requirements.txt`.

## Run it
Open Command Prompt in this folder:

```bash
python -m pip install -r requirements.txt
python password_cli.py
```

To open the desktop app:

```bash
python password_gui.py
```

## Tests
```bash
python -m unittest -v
```

For more details, see `DOCUMENTATION.md`. Keep generated passwords private and use a different password for each account.
