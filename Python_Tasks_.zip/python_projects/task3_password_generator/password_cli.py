"""Password Generator - Beginner tier (command line, uses random + string)."""
import random
import string


def ask_length():
    while True:
        raw = input("Password length (minimum 8): ").strip()
        try:
            n = int(raw)
        except ValueError:
            print("  Error: please enter a whole number.")
            continue
        if n < 8:
            print("  Error: length must be at least 8.")
        elif n > 128:
            print("  Error: length must be at most 128.")
        else:
            return n


def ask_yes_no(question):
    while True:
        a = input(question + " (y/n): ").strip().lower()
        if a in ("y", "yes"):
            return True
        if a in ("n", "no"):
            return False
        print("  Please answer y or n.")


def ask_types():
    while True:
        options = [
            ("uppercase letters", string.ascii_uppercase),
            ("lowercase letters", string.ascii_lowercase),
            ("numbers", string.digits),
            ("symbols", "!@#$%^&*()-_=+"),
        ]
        chosen = [chars for label, chars in options if ask_yes_no(f"Include {label}?")]
        if len(chosen) >= 2:
            return chosen
        print("  Error: select at least 2 character types. Let's try again.")


def make_password(length, pools):
    chars = [random.choice(p) for p in pools]          # one from each chosen type
    allchars = "".join(pools)
    chars += [random.choice(allchars) for _ in range(length - len(chars))]
    random.shuffle(chars)
    return "".join(chars)


def main():
    print("=== Random Password Generator ===")
    while True:
        length = ask_length()
        pools = ask_types()
        print("\nYour password:", make_password(length, pools), "\n")
        if not ask_yes_no("Generate another password?"):
            break
    print("Goodbye!")


if __name__ == "__main__":
    main()
