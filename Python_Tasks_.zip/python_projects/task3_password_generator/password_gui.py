"""Password Generator - Advanced tier (tkinter + secrets + pyperclip)."""
import tkinter as tk
from tkinter import ttk, messagebox
from collections import deque

from pwgen_core import generate_password, password_strength, MIN_LENGTH, MAX_LENGTH

try:
    import pyperclip
except ImportError:
    pyperclip = None

STRENGTH_COLOURS = {"Weak": "#F44336", "Medium": "#FF9800", "Strong": "#4CAF50"}


class PasswordApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Secure Password Generator")
        self.geometry("460x520")
        self.resizable(False, False)
        self.history = deque(maxlen=5)   # in memory only - never written to disk
        self._build()

    def _build(self):
        frm = ttk.Frame(self, padding=15)
        frm.pack(fill="both", expand=True)

        ttk.Label(frm, text="Length:").grid(row=0, column=0, sticky="w")
        self.length_var = tk.IntVar(value=16)
        ttk.Scale(frm, from_=MIN_LENGTH, to=64, orient="horizontal", length=220,
                  command=lambda v: self.length_var.set(int(float(v)))).grid(row=0, column=1, padx=6)
        self.spin = ttk.Spinbox(frm, from_=MIN_LENGTH, to=MAX_LENGTH, width=5,
                                textvariable=self.length_var)
        self.spin.grid(row=0, column=2)

        self.upper = tk.BooleanVar(value=True)
        self.lower = tk.BooleanVar(value=True)
        self.digits = tk.BooleanVar(value=True)
        self.symbols = tk.BooleanVar(value=True)
        self.ambig = tk.BooleanVar(value=False)
        opts = ttk.LabelFrame(frm, text="Character types (choose at least 2)", padding=8)
        opts.grid(row=1, column=0, columnspan=3, sticky="ew", pady=10)
        ttk.Checkbutton(opts, text="Uppercase (A-Z)", variable=self.upper).pack(anchor="w")
        ttk.Checkbutton(opts, text="Lowercase (a-z)", variable=self.lower).pack(anchor="w")
        ttk.Checkbutton(opts, text="Numbers (0-9)", variable=self.digits).pack(anchor="w")
        ttk.Checkbutton(opts, text="Symbols (!@#$...)", variable=self.symbols).pack(anchor="w")
        ttk.Checkbutton(opts, text="Exclude ambiguous characters (0 O l 1 I)",
                        variable=self.ambig).pack(anchor="w", pady=(6, 0))

        ttk.Button(frm, text="Generate password", command=self.generate).grid(
            row=2, column=0, columnspan=3, pady=6)

        self.pw_var = tk.StringVar()
        ttk.Entry(frm, textvariable=self.pw_var, font=("Courier", 13), state="readonly",
                  justify="center").grid(row=3, column=0, columnspan=3, sticky="ew", pady=6)

        self.bar = tk.Canvas(frm, height=16, bg="#DDDDDD", highlightthickness=0)
        self.bar.grid(row=4, column=0, columnspan=3, sticky="ew")
        self.strength_lbl = ttk.Label(frm, text="Strength: -")
        self.strength_lbl.grid(row=5, column=0, columnspan=3, pady=4)

        self.status = ttk.Label(frm, text="", foreground="#555555")
        self.status.grid(row=6, column=0, columnspan=3)

        ttk.Button(frm, text="Copy to clipboard", command=self.copy).grid(
            row=7, column=0, columnspan=3, pady=4)

        hist = ttk.LabelFrame(frm, text="Last 5 passwords (this session only)", padding=6)
        hist.grid(row=8, column=0, columnspan=3, sticky="ew", pady=8)
        self.hist_list = tk.Listbox(hist, height=5, font=("Courier", 10))
        self.hist_list.pack(fill="x")
        frm.columnconfigure(1, weight=1)

    def _selected_count(self):
        return sum(v.get() for v in (self.upper, self.lower, self.digits, self.symbols))

    def generate(self):
        try:
            length = int(self.spin.get())
        except (ValueError, tk.TclError):
            messagebox.showerror("Invalid length", "Length must be a whole number.")
            return
        if self._selected_count() < 2:
            messagebox.showerror("Not enough types", "Select at least 2 character types.")
            return
        try:
            pw = generate_password(length, self.upper.get(), self.lower.get(),
                                   self.digits.get(), self.symbols.get(), self.ambig.get())
        except ValueError as err:
            messagebox.showerror("Cannot generate", str(err))
            return
        self.pw_var.set(pw)
        self._update_strength(pw)
        self.history.appendleft(pw)
        self.hist_list.delete(0, "end")
        for item in self.history:
            self.hist_list.insert("end", item)
        self.copy(auto=True)

    def _update_strength(self, pw):
        label, score = password_strength(pw)
        self.update_idletasks()
        width = self.bar.winfo_width() or 400
        self.bar.delete("all")
        self.bar.create_rectangle(0, 0, width * score / 100, 16,
                                  fill=STRENGTH_COLOURS[label], width=0)
        self.strength_lbl.config(text=f"Strength: {label} ({score}/100)")

    def copy(self, auto=False):
        pw = self.pw_var.get()
        if not pw:
            if not auto:
                messagebox.showinfo("Nothing to copy", "Generate a password first.")
            return
        try:
            if pyperclip:
                pyperclip.copy(pw)
            else:                       # fallback if pyperclip is not installed
                self.clipboard_clear()
                self.clipboard_append(pw)
                self.update()
            self.status.config(text="Copied to clipboard \u2713")
        except Exception as err:        # pyperclip raises on systems without a clipboard tool
            try:
                self.clipboard_clear()
                self.clipboard_append(pw)
                self.status.config(text="Copied to clipboard \u2713")
            except tk.TclError:
                self.status.config(text=f"Copy failed: {err}")


if __name__ == "__main__":
    PasswordApp().mainloop()
