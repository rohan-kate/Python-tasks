"""Password generation logic using the cryptographically secure `secrets` module."""
import secrets
import string

AMBIGUOUS = set("0Ol1I|`'\"")
MIN_LENGTH = 8
MAX_LENGTH = 128


def build_pools(upper, lower, digits, symbols, exclude_ambiguous=False):
    pools = []
    if upper:
        pools.append(string.ascii_uppercase)
    if lower:
        pools.append(string.ascii_lowercase)
    if digits:
        pools.append(string.digits)
    if symbols:
        pools.append("!@#$%^&*()-_=+[]{};:,.<>?/~")
    if exclude_ambiguous:
        pools = ["".join(c for c in p if c not in AMBIGUOUS) for p in pools]
    return pools


def generate_password(length, upper=True, lower=True, digits=True, symbols=True,
                      exclude_ambiguous=False):
    """Generate a password guaranteed to contain >=1 char from every selected type."""
    if not isinstance(length, int) or length < MIN_LENGTH or length > MAX_LENGTH:
        raise ValueError(f"Length must be a whole number between {MIN_LENGTH} and {MAX_LENGTH}.")
    pools = build_pools(upper, lower, digits, symbols, exclude_ambiguous)
    if len(pools) < 2:
        raise ValueError("Select at least 2 character types.")
    chars = [secrets.choice(p) for p in pools]            # one from each type
    allchars = "".join(pools)
    chars += [secrets.choice(allchars) for _ in range(length - len(chars))]
    secrets.SystemRandom().shuffle(chars)                 # secure shuffle
    return "".join(chars)


def password_strength(password):
    """Return (label, score 0-100) from length and character diversity."""
    kinds = sum([
        any(c.islower() for c in password),
        any(c.isupper() for c in password),
        any(c.isdigit() for c in password),
        any(not c.isalnum() for c in password),
    ])
    length = len(password)
    score = min(length, 24) / 24 * 60 + kinds / 4 * 40
    if length < 10 or kinds < 2:
        score = min(score, 39)
    if score < 40:
        return "Weak", int(score)
    if score < 75:
        return "Medium", int(score)
    return "Strong", int(score)
