# Random Password Generator

## About the project
The Random Password Generator creates passwords based on the length and character types selected by the user. It has a beginner command-line version and a desktop version with extra options. The advanced generator uses Python's `secrets` module to make passwords suitable for security-sensitive use.

## Main features
- Choose password length.
- Include uppercase letters, lowercase letters, numbers and symbols.
- Option to avoid characters that can be easily confused, such as `O` and `0`.
- Show a simple strength estimate for generated passwords.
- Copy a generated password from the desktop app when clipboard support is available.
- Generate another password without restarting the program.

## Files in this folder
- `password_cli.py` – beginner command-line version.
- `password_gui.py` – desktop version.
- `pwgen_core.py` – secure password generation and strength-checking functions.
- `test_pwgen.py` – automated tests.
- `requirements.txt` – optional clipboard package.

## Requirements
Install Python 3.10 or later. Tkinter is normally included with Python on Windows. Clipboard support uses `pyperclip`.

## How to run
Open Command Prompt in this folder and run:

```bash
python -m pip install -r requirements.txt
python password_cli.py
```

To open the desktop version, run:

```bash
python password_gui.py
```

## Run the tests
```bash
python -m unittest -v
```

## Note
The strength label is a simple estimate, not a guarantee that a password is impossible to guess. Do not share generated passwords or save them in public files. Use a unique password for every important account.
