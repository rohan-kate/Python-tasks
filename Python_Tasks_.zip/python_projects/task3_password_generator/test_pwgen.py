import string, unittest
from pwgen_core import generate_password, password_strength, AMBIGUOUS


class TestPwgen(unittest.TestCase):
    def test_length_and_types(self):
        for _ in range(300):
            pw = generate_password(12, True, True, True, True)
            self.assertEqual(len(pw), 12)
            self.assertTrue(any(c.isupper() for c in pw))
            self.assertTrue(any(c.islower() for c in pw))
            self.assertTrue(any(c.isdigit() for c in pw))
            self.assertTrue(any(c in "!@#$%^&*()-_=+[]{};:,.<>?/~" for c in pw))

    def test_subset_only(self):
        pw = generate_password(20, upper=False, lower=True, digits=True, symbols=False)
        self.assertTrue(all(c in string.ascii_lowercase + string.digits for c in pw))

    def test_exclude_ambiguous(self):
        for _ in range(300):
            self.assertFalse(set(generate_password(30, exclude_ambiguous=True)) & AMBIGUOUS)

    def test_validation(self):
        with self.assertRaises(ValueError):
            generate_password(7)
        with self.assertRaises(ValueError):
            generate_password(12, upper=True, lower=False, digits=False, symbols=False)

    def test_strength(self):
        self.assertEqual(password_strength("abcdefgh")[0], "Weak")
        self.assertEqual(password_strength("Abcdef12ghij")[0], "Medium")
        self.assertEqual(password_strength("Xk9#mP2$vL7!qR4@wZ8&nB5")[0], "Strong")


if __name__ == "__main__":
    unittest.main()
